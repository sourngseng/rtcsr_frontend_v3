<?php

return array (
  'manage_location' => 'Manage Locations',
  'id' => 'ID',
  'title' => 'Location Name',
  'description' => 'Description',
  'code' => 'Code',
  'photo' => 'Photo',
  'created_at' => 'Created At',
  'status' => 'Status',
);
