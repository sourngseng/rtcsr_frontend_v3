<?php

return [
  'manageOrder'       => 'Manage Orders',
  'allorders'         => 'All Orders',
  'productManagement' => 'Manage Products',
  'affiliate'        => 'Affiliate',
  'all_affiliate'    => 'All Affilate',
  'product_singular'  => 'Product',
  'product'           => 'Products',
  'all_product'       => 'All Products',
  'catalog_singulaar' => 'Catalog',
  'catalog'           => 'Catalogs',
  'bulkupload'        => 'Bulk Product Upload',
  'withdraw'          => 'Withdraw',
  'order'            => 'Orders',
  'order_singular'   => 'Order',
  'order_pending'     => 'Orders Pending!',
  'order_process'     => 'Orders Procsessing!',
  'order_complete'    => 'Orders Completed!',
  'total_product'     => 'Total Products!',
  'total_sold'        => 'Total Item Sold!',
  'total_earning'     => 'Total Earnings!',
];
