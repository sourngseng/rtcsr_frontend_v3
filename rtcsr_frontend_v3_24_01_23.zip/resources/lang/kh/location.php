<?php

return array (
  'manage_location' => 'គ្រប់គ្រងទីតាំង',
  'id' => 'ល.រ',
  'title' => 'ឈ្មោះទីកន្លែង',
  'description' => 'អធិប្បាយពន្យល់',
  'code' => 'កូដទីកន្លែង',
  'photo' => 'រូបភាព',
  'created_at' => 'ថ្ងៃខែឆ្នាំបង្កើត',
  'status' => 'ស្ថានភាព',
);
