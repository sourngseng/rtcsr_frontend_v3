<?php

return array (
    'menus' =>
        array (            
            'home' => 'ទំព័រដើម',
            'about' => 'អំពីយើង',
            'courses' => 'មុខវិជ្ជា ឬជំនាញ',
            'event' => 'ព្រឹត្តិការណ៍',
            'pages' => 'ទំព័រផ្សេងៗ',
            'blogs' => 'ព័ត៌មានផ្សេងៗ',
            'contact' => 'ទំនាក់ទំនង',
            'register' => 'ចុះឈ្មោះ',
            'login' => 'ចូលប្រើ',
        ),
        
);
