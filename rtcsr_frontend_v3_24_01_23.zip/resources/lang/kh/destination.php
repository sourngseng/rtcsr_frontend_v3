<?php

return array (
  'manage_destinations' => 'គ្រប់គ្រងទិសដៅ',
  'id' => 'ល.រ',
  'title' => 'ចំណងជើង',
  'description' => 'អធិប្បាយ',
  'link' => 'លីងភ្ជាប់',
  'photo' => 'រូបភាព',
  'created_at' => 'ថ្ងៃខែឆ្នាំបង្កើត',
  'status' => 'ស្ថានភាព',
);
