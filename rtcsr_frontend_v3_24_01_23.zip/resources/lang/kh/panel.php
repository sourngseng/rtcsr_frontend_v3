<?php

return [
    'site_title' => 'Role Permission',
];
