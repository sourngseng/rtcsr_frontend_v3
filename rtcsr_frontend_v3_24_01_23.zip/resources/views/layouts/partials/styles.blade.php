<!--===== Vendor CSS (Bootstrap & Icon Font) =====-->
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/bootstrap.min.css">
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/fontawesome.min.css">
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/default.css">


<!--===== Plugins CSS (All Plugins Files) =====-->
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/animate.min.css">
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/slick.css">
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/plugins/magnific-popup.css">

<!--====== Main Style CSS ======-->
<!-- <link rel="stylesheet" href="assets/css/style.css"> -->
<link rel="stylesheet" href="{{asset('frontend')}}/assets/css/style.min.css">