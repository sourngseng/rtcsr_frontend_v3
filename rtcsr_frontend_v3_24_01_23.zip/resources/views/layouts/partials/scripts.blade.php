<!--====== Jquery js ======-->
<script src="{{asset('frontend')}}/assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/vendor/modernizr-3.7.1.min.js"></script>

<!--====== All Plugins js ======-->
<script src="{{asset('frontend')}}/assets/js/plugins/popper.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/bootstrap.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/slick.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/jquery.magnific-popup.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/imagesloaded.pkgd.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/isotope.pkgd.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/wow.min.js"></script>
<script src="{{asset('frontend')}}/assets/js/plugins/ajax-contact.js"></script>


<!--====== Main Activation  js ======-->
<script src="{{asset('frontend')}}/assets/js/main.js"></script>