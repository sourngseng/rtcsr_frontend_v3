<div class="counter-area">
    <div class="container single-courses">
        <div class="counter-wrapper bg_cover" style="background-image: url({{asset('images/page_banner.webp')}});">
            <div class="row">
                <div class="col-sm-3 col-6 counter-col">
                    <div class="single-counter mt-30 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.2s">
                        <span class="counter-count"><span class="count" data-count="3530">0</span> +</span>
                        <p>សិស្ស និស្សិត</p>
                    </div>
                </div>
                <div class="col-sm-3 col-6 counter-col">
                    <div class="single-counter mt-30 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.4s">
                        <span class="counter-count"><span class="count" data-count="15">0</span> +</span>
                        <p>​ឯកទេស និងជំនាញ</p>
                    </div>
                </div>
                <div class="col-sm-3 col-6 counter-col">
                    <div class="single-counter mt-30 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.6s">
                        <span class="counter-count"><span class="count" data-count="302">0</span> +</span>
                        <p>កំពុងសិក្សា</p>
                    </div>
                </div>
                <div class="col-sm-3 col-6 counter-col">
                    <div class="single-counter mt-30 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.8s">
                        <span class="counter-count"><span class="count" data-count="30">0</span> +</span>
                        <p>មុខវិជ្ជា</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>