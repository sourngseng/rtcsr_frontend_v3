<section class="newsletter-area">
    <div class="container single-courses">
        <div class="newsletter-wrapper bg_cover wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s"
            style="background-image: url({{asset('images/page_banner.webp')}});">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <div class="section-title-2 mt-25">
                        <h2 class="title">Subscribe our Newsletter</h2>
                        <span class="line"></span>
                        <p>ទទួលបាននូវព័ត៌មានថ្មីពីការបណ្តុះបណ្តាលរបស់យើងរាល់គ្នា។</p>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="newsletter-form mt-30">
                        <form action="#">
                            <input type="text" placeholder="Enter your email here" class="single-courses">
                            <button class="main-btn main-btn-2">Subscribe now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>