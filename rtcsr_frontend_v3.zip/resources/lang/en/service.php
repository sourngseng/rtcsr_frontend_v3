<?php

return array (
  'manage_service' => 'Manage Service',
  'id' => 'ID',
  'title' => 'Title',
  'option' => 'Option',
  'photo' => 'Photo',
  'created_at' => 'Created At',
  'status' => 'Status',
);
