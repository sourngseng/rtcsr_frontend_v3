<?php

return array (
  'manage' => 'Manage Customer',
  'id' => 'ID',
  'name' => 'Customer Name',
  'phone' => 'Phone',
  'email' => 'Email',
  'address' => 'Address',
  'city' => 'City',
  'photo' => 'Photo',
  'created_at' => 'Created At',
  'status' => 'Status',
);
