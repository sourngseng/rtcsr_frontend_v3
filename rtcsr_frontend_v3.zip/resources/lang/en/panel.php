<?php

return array (
  'site_title' => 'Role Permission',
);
