<?php

return array (
  'manage_driver' => 'Manage Driver',
  'id' => 'ID',
  'name' => 'Driver Name',
  'phone' => 'Phone',
  'license' => 'License',
  'address' => 'Address',
  'city' => 'City',
  'photo' => 'Photo',
  'created_at' => 'Created At',
  'status' => 'Status',
);
