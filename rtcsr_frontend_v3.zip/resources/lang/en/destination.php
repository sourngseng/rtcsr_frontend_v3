<?php

return array (
  'manage_destinations' => 'Manage Destinations',
  'id' => 'ID',
  'title' => 'Title',
  'description' => 'Description',
  'link' => 'Link',
  'photo' => 'Photo',
  'created_at' => 'Created At',
  'status' => 'Status',
);
