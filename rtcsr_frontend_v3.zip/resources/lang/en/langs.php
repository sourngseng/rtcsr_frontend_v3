<?php

return array (
    'menus' =>
        array (            
            'home' => 'Home',
            'about' => 'About',
            'courses' => 'Courses',
            'event' => 'Events',
            'pages' => 'Pages',
            'blogs' => 'Blogs',
            'contact' => 'Contact',
            'register' => 'Register',
            'login' => 'Login',
        ),
        
);
