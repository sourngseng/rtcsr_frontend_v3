<?php

return array (
  'manage_service' => 'គ្រប់គ្រងសេវាកម្ម',
  'id' => 'ល.រ',
  'title' => 'ចំណងជើង',
  'option' => 'ជម្រើស',
  'photo' => 'រូបភាព',
  'created_at' => 'ថ្ងៃខែឆ្នាំបង្កើត',
  'status' => 'ស្ថានភាព',
);
