<?php

return [
  'manageOrder'       => 'គ្រប់គ្រង ការកម្មង់',
  'allorders'         => 'ការកម្មង់ទាំងអស់',
  'productManagement' => 'គ្រប់គ្រង ផលិតផល',
  'affilliate'        =>'Affilliate',
  'all_affilliate'    => 'All Affilate',
  'product_singular'  => 'ផលិតផល',
  'product'           => 'ផលិតផល',
  'all_product'       => 'ផលិតផលទាំងអស់',
  'catalog_singular' => 'Catalog',
  'catalog'           => 'Catalogs',
  'bulkupload'        => 'Bulk Product Upload',
  'withdraw'          => 'Withdraws',
  'order'            => 'Orders',
  'order_singular'   => 'Order',
  'order_pending'     => 'Orders Pending!',
  'order_process'     => 'Orders Procsessing!',
  'order_complete'    => 'Orders Completed!',
  'total_product'     => 'Total Products!',
  'total_sold'        => 'Total Item Sold!',
  'total_earning'     => 'Total Earnings!',
];
