<section class="slider-area slider-active">

    <?php $__currentLoopData = $slides['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="single-slider d-flex align-items-center bg_cover "
        style="background-image: url(<?php echo e($slider['image']); ?>);background-size: cover;">
        <div class="container">
            <div class="slider-content">
                <h1 class="text-primary" data-animation="fadeInLeft" data-delay="0.2s"><?php echo e($slider['title']); ?></h1>
                <h1 class="text-primary" data-animation="fadeInLeft" data-delay="0.2s"><?php echo e($slider['description']); ?></h1>
                <ul class="slider-btn">
                    <li><a data-animation="fadeInUp" data-delay="0.6s" class="main-btn main-btn-2" href="/courses">View
                            Courses</a></li>
                    <li><a data-animation="fadeInUp" data-delay="1s" class="main-btn" href="#">Learn more</a></li>
                </ul>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</section><?php /**PATH D:\RTCSR Projects\rtcsr_frontend_v3\resources\views/pages/home/home_slider.blade.php ENDPATH**/ ?>