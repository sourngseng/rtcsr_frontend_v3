<?php $__env->startSection('title'); ?>
About Us
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<!--====== Page Banner Start ======-->
<section class="page-banner">
    <div class="page-banner-bg bg_cover" style="background-image: url(<?php echo e(asset('assets/images/page-banner.webp')); ?>);">
        <div class="container">
            <div class="banner-content text-center">
                <h2 class="title">About Us</h2>
            </div>
        </div>
    </div>
</section>

<!--====== Page Banner Ends ======-->

<!--====== About Start ======-->

<h1 class="text-center m-3">ប្រវត្តិរបស់វិទ្យាស្ថាន</h1>
<div class="container px-4">
    <div class="row gx-5">
        <div class="col">
            <div class="p-3 border bg-light">
                <iframe width="600" height="400" src="https://www.youtube.com/embed/9pKv1_L3IhA"
                    title="វិទ្យាស្ថានពហុបច្ចេកទេសភូមិភាគតេជោសែនសៀមរាប (RPITSSR Long Version)"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            </div>
        </div>
        <div class="col">
            <div class="p-3 border bg-light">
                <p class="fs-4 lh-base">
                    វិទ្យាស្ថានបានបង្កើតឡើងនៅឆ្នាំ១៩៩៣ ក្រោមការ​ឧបត្ថម្ភជំនួយបច្ចេកទេស
                    ​និងថវិកាពី​អង្គការពលកម្ម​អន្តរជាតិ​UNDP/ILO ​
                    (ពីឆ្នាំ១៩៩៣ ដល់ឆ្នាំ១៩៩៨)ដែលមានឈ្មោះថាមជ្ឈមណ្ឌលបណ្តុះបណ្តាលវិជ្ជាជីវៈខេត្តសៀមរាបProvincial​
                    Training​ Center
                    ២/ ពីឆ្នាំ១៩៩៨ ដល់ ២០០៤ ស្ថិតក្រោមការគ្រប់គ្រងរបស់​ក្រសួងអប់រំ យុវជន និងកីឡា
                    ៣/ ពីឆ្នាំ២០០៤ ដល់បច្ចុប្បន្នស្ថិតក្រោមការ​គ្រប់គ្រងរបស់ក្រសួងការងារ និងបណ្តុះបណ្តាលវិជ្ជាជីវៈ
                    ៤/ នៅឆ្នាំ២០១៤ មជ្ឈមណ្ឌលបានតម្លើងកម្រិតបណ្តុះបណ្តាល
                    និងបានប្តូឈ្មោះទៅជាវិទ្យាស្ថានពហុបច្ចេកទេស​ភូមិភាគតេជោសែនសៀមរាបរហូតដល់​បច្ចុប្បន្ន។
                </p>
            </div>
        </div>
    </div>
</div>
<h1 class="text-center m-3">សាររបស់នាយិកាវិទ្យាស្ថាន</h1>
<div class="container">
    <div class="p-3 border bg-light">
        <p class="fs-4 lh-base " style="text-indent: 30px">
            យើងខ្ញុំគណៈគ្រប់គ្រង មានមោទនភាព និងថ្លៃអំណរគុណដល់សិក្ខាកាម សិស្ស
            និស្សិតទាំងអស់ដែលសម្រេចចិត្តយ៉ាងត្រឹមត្រូវជ្រើសរើសយកវិទ្យាស្ថានពហុបច្ចេកទេសភូមិភាគតេជោសែនសៀមរាប
            ក្នុងការសិក្សាជំនាញបច្ចេកទេស និងវិជ្ជាជីវៈ។
            យើងខ្ញុំគណៈគ្រប់គ្រង លោកគ្រូ អ្នកគ្រូទាំងអស់នឹង ខិតខំប្រឹងប្រែង ឱ្យអស់ពីសមត្ថភាព ក្នុងការផ្តល់ចំណេះ ដឹង
            ជំនាញ និងឥរិយាបថសមរម្យ ដល់សិក្ខាកាម សិស្ស និសិត្សប្រកបដោយគុណភាព និងឆ្លើយតបបាននូវតម្រូវការការងារ។
        </p>
    </div>
</div>
<h4 class="text-center m-4">ហេតុអ្វីបានជាសម្រេចចិត្តជ្រើសរើសវិទ្យាស្ថានពហុបច្ចេកទេសភូមិភាគតេជោសែនសៀមរាប?</h4>
<div class="container">
    <div class="p-3 border bg-light">
        <div class="accordion" id="accordionExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <strong>មុនពេលបណ្តុះបណ្តាល</strong>
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                    data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        ប្រឹក្សាយោបល់ និងតម្រង់ទិសមុនជ្រើសរើសជំនាញ
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        <strong> កំឡុងពេលបណ្តុះបណ្តាល</strong>
                    </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                    data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        កម្មសិក្សា និងការងារត្រូវបានធានា
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        <strong> ក្រោយពេលបណ្តុះបណ្តាល</strong>
                    </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                    data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        កម្មសិក្សា និងការងារត្រូវបានធានា
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- envirenment area start -->

    
        
            
                
                    
                    
                    
                    
                    
                
            
                
                    
                        
                        
                    
                        
                        
                    
                        
                        
                    
                        
                        

                    
                        
                        
                    
                        
                        
                    
                        
                        
                    
                        
                        
                    
                
            
        
    

<!-- envirenment area end -->

<!--====== Features Start ======-->


    
        
            
                
                    
                    
                
            
                
                    
                        
                            
                                
                                
                            
                                
                                
                            
                        
                            
                                
                                
                            
                                
                                
                            
                        
                            
                                
                                
                            
                                
                                
                            
                        

                    
                        
                            
                                
                                
                            
                                
                                
                            
                        
                            
                                
                                
                            
                                
                                
                            
                        
                            
                                
                                
                            
                                
                                
                            
                        
                    
                
            
        
    

<!--====== Features Ends ======-->

<!--====== Campus Visit Start ======-->


    
        
            
                
                    
                    
                    
                    
                    
                    
                
            
                
                    
                        
                        
                    
                        
                        
                    
                
            
        
    

<!--====== Campus Visit Ends ======-->

<!--====== Counter Start ======-->


    
        
            
                
                    
                        
                        
                        
                    
                
                    
                        
                        
                        
                    
                
                    
                        
                        
                        
                    
                
                    
                        
                        
                        
                    
                
            
        
    

<!--====== Counter Ends ======-->

<!--====== Teachers Start ======-->


    
        
            
                
                    
                    
                    
                
            
        
            
                
                
                    
                        
                            
                                
                                
                                
                                
                                
                            
                        
                            
                                
                                
                            
                        
                            
                            
                            
                        
                    
                
                
            
        
    

<!--====== Teachers Ends ======-->

<!--====== Testimonials Start ======-->

<section class="testimonials-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4">
                <div class="testimonials-title">
                    <h2 class="title">Our Students Review</h2>
                    <span class="line"></span>
                    <p>Even slightly believable. If you are going use a passage of Lorem Ipsum need desire to obtain
                        pain of itself, because it is pain de sires to obtain pain of itself occur</p>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="testimonials-wrapper">
                    <div class="testimonials-shape shape-1"></div>
                    <div class="testimonials-shape shape-2"></div>
                    <div class="testimonials-shape shape-3"></div>

                    <div class="row no-gutters">
                        <div class="col-lg-6 col-md-5">
                            <div class="testimonials-image">
                                <div class="single-testimonial-image">
                                    <img src="https://template.hasthemes.com/edumate-v1/edumate/assets/images/testimonials-1.webp"
                                        width="313" height="579" alt="testimonials">
                                </div>
                                <div class="single-testimonial-image">
                                    <img src="https://template.hasthemes.com/edumate-v1/edumate/assets/images/testimonials-2.webp"
                                        width="313" height="579" alt="testimonials">
                                </div>
                                <div class="single-testimonial-image">
                                    <img src="https://template.hasthemes.com/edumate-v1/edumate/assets/images/testimonials-1.webp"
                                        width="313" height="579" alt="testimonials">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-7">
                            <div class="testimonials-content">
                                <div class="single-testimonial-content">
                                    <div class="content-text">
                                        <i class="fas fa-quote-right"></i>
                                        <p>Best pleasure rationally encounter consequences that are very nice a again is
                                            there anyone who loves or desires to obtain pain of itself</p>
                                    </div>
                                    <div class="content-meta">
                                        <p class="name">Alex Smith</p>
                                        <p class="designation">CEO, Xelopex Group</p>
                                    </div>
                                </div>
                                <div class="single-testimonial-content">
                                    <div class="content-text">
                                        <i class="fas fa-quote-right"></i>
                                        <p>Best pleasure rationally encounter consequences that are very nice a again is
                                            there anyone who loves or desires to obtain pain of itself</p>
                                    </div>
                                    <div class="content-meta">
                                        <p class="name">Alex Smith</p>
                                        <p class="designation">CEO, Xelopex Group</p>
                                    </div>
                                </div>
                                <div class="single-testimonial-content">
                                    <div class="content-text">
                                        <i class="fas fa-quote-right"></i>
                                        <p>Best pleasure rationally encounter consequences that are very nice a again is
                                            there anyone who loves or desires to obtain pain of itself</p>
                                    </div>
                                    <div class="content-meta">
                                        <p class="name">Alex Smith</p>
                                        <p class="designation">CEO, Xelopex Group</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== Testimonials Ends ======-->




    
        
            
                
                    
                        
                        
                        
                        
                    
                
                    
                        
                            
                            
                            
                        
                    
                
            
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RTCSR Projects\rtcsr_frontend_v3\resources\views/pages/about/index_about.blade.php ENDPATH**/ ?>