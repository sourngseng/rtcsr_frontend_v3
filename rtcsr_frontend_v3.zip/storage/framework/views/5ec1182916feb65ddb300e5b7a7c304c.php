<?php $__env->startSection('title', 'Teachers Lists'); ?>
<?php $__env->startSection('content'); ?>

<!--====== Page Banner Start ======-->

<section class="page-banner">
    <div class="page-banner-bg bg_cover"
        style="background-image: url(https://template.hasthemes.com/edumate-v1/edumate/assets/images/page-banner.webp);">
        <div class="container">
            <div class="banner-content text-center">
                <h2 class="title">Our Teachers</h2>
            </div>
        </div>
    </div>
</section>

<!--====== Page Banner Ends ======-->

<!--====== Teachers Start ======-->

<section class="teachers-page">
    <div class="container">

        <div class="row teachers-row">
            <?php $__currentLoopData = $teachers['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 teachers-col">
                <div class="single-teacher mt-80 text-center">
                    <div class="teacher-social">
                        <ul class="social">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="teacher-image">
                        <a href="#">
                            <img src="<?php echo e($item['image']); ?>" alt="teacher" style="height: 310px;">
                        </a>
                    </div>
                    <div class="teacher-content">
                        <h4 class="name"><a href="#"><?php echo e($item['first_name']); ?> <?php echo e($item['last_name']); ?></a></h4>
                        <span class="designation">Science lecturer</span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

</section>

<!--====== Teachers Ends ======-->




    
        
            
                
                    
                        
                        
                        
                        
                    
                
                    
                        
                            
                            
                            
                        
                    
                
            
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RTCSR Projects\rtcsr_frontend_v3\resources\views/pages/teacher/index_teacher.blade.php ENDPATH**/ ?>