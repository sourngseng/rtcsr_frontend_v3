<?php $__env->startSection('title', 'Events'); ?>
<?php $__env->startSection('content'); ?>



<!--====== Page Banner Start ======-->

<section class="page-banner">
    <div class="page-banner-bg bg_cover"
        style="background-image: url(https://template.hasthemes.com/edumate-v1/edumate/assets/images/page-banner.webp);">
        <div class="container">
            <div class="banner-content text-center">
                <h2 class="title">Events</h2>
            </div>
        </div>
    </div>
</section>

<!--====== Page Banner Ends ======-->

<!--====== Event Start ======-->

<section class="event-page">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="event-menu pt-20 text-center">
                    <ul class="menu-items">
                        <li data-filter="*" class="active">All</li>
                        <li data-filter=".happening">Happening</li>
                        <li data-filter=".upcoming">Upcoming</li>
                        <li data-filter=".expired">Expired</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="event-wrapper">
            <div class="row grid">
                <div class="col-lg-3 col-sm-6 happening">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 expired">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 happening">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 expired">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 upcoming">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 expired">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 happening">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 upcoming">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 expired">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 expired">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 happening">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 upcoming">
                    <div class="single-event text-center mt-30">
                        <span class="time">10.35 am to 1.00 pm</span>
                        <span class="date">25 May, 2020</span>
                        <h4 class="event-title"><a href="event-details.html">Micro Biological Workshop</a></h4>
                        <p class="place">Place: Central Hall, New York</p>
                        <a href="event-details.html" class="more">Read more <i class="far fa-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <ul class="pagination-items text-center">
            <li><a class="active" href="#">01</a></li>
            <li><a href="#">02</a></li>
            <li><a href="#">03</a></li>
            <li><a href="#">04</a></li>
            <li><a href="#">05</a></li>
        </ul>
    </div>
</section>

<!--====== Event Ends ======-->




    
        
            
                
                    
                        
                        
                        
                        
                    
                
                    
                        
                            
                            
                            
                        
                    
                
            
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RTCSR Projects\rtcsr_frontend_v3\resources\views/pages/event/index_event.blade.php ENDPATH**/ ?>